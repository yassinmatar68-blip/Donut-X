# DONUT X — Minecraft Bedrock Companion (Android)

A Kotlin + Jetpack Compose starter app with a black/neon-red interface.

## Included modules
- Home dashboard
- Coordinate Hub (session-only saved coordinates)
- Block Vision filters for furnaces, chests, hoppers, note blocks, diamond/netherite blocks, all standard ores, deepslate ore variants, Nether gold/quartz ores and ancient debris; per-block enable/disable and cycling highlight colors; configurable radius setting; authorized base waypoint records.
- Pack Manager (selects files using Android's Storage Access Framework; Minecraft performs the actual import)
- Bedrock RakNet UDP ping attempt
- Mod Library starter catalog
- PVP practice checklist
- Offline ore reference
- Skin Studio file picker

## Requirements
- Android Studio (recent stable version)
- JDK 17
- Android SDK 35
- Internet permission is used only by the server ping feature.

## Open and build
1. Extract the ZIP.
2. Open the `DONUT_X_Android` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Connect an Android device with USB debugging enabled, or start an emulator.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Find the debug APK under `app/build/outputs/apk/debug/app-debug.apk`.

## Important implementation notes
- This is a companion app, not a Minecraft launcher or modified game client.
- Coordinate and base entries are currently in-memory and reset when the app process is restarted. Block filter settings are also currently session-only.
- Pack Manager selects and lists files; it does not silently install or activate packs.
- Server Ping sends a RakNet unconnected ping to the configured host and UDP port. Some servers do not reply to status queries, so a timeout does not prove the server is offline.
- Ore Finder is an offline reference, not an X-ray or multiplayer scanner. Block Vision currently configures filters, colors and a radius preference; live world scanning is not implemented.
- Skin Studio selects local images; account upload and Minecraft skin application are not implemented.
- The Mod Library is a starter catalog and does not download third-party files yet.

## Next development milestones
1. Add Room persistence for coordinates, bases, pack history and training progress.
2. Add validated import/export for coordinate backups.
3. Add thumbnail previews for skin and pack files.
4. Add a maintained add-on catalog with source/license metadata.
5. Add a Bedrock server query details parser and connection history.
6. Add tests for coordinate validation and RakNet packet parsing.


## Build the APK online with GitHub Actions (no PC required for building)

1. Create a new GitHub repository.
2. Upload the contents of this project folder to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable workflows if GitHub asks.
4. The workflow named **Build DONUT X APK** runs on pushes to `main`. You can also open it and choose **Run workflow**.
5. When the run finishes successfully, open the run, find **Artifacts**, and download **DONUT-X-debug-APK**.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

The APK is a debug build for testing. This workflow builds the companion app source; it does not add live Minecraft world scanning or multiplayer X-ray features.
