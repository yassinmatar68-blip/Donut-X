package com.donutx.companion

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.random.Random

private val NeonRed = Color(0xFFFF2448)
private val Panel = Color(0xFF171316)
private val Background = Color(0xFF080808)
private val Muted = Color(0xFFB8AEB1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DonutXApp() }
    }
}

private data class SavedPoint(val name: String, val x: String, val y: String, val z: String, val note: String)

@Composable
private fun DonutXApp() {
    val context = LocalContext.current
    val tabs = listOf("Home", "Coords", "Packs", "Server", "Mods", "PVP", "Ores", "Bases", "Skins")
    var current by remember { mutableStateOf("Home") }
    val coordinates = remember { mutableStateListOf<SavedPoint>() }
    val bases = remember { mutableStateListOf<SavedPoint>() }
    val packs = remember { mutableStateListOf<String>() }
    val skins = remember { mutableStateListOf<Uri>() }

    val packPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            packs.add(it.lastPathSegment?.substringAfterLast('/') ?: "Imported pack")
        }
    }
    val skinPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            skins.add(it)
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = NeonRed,
            secondary = NeonRed,
            background = Background,
            surface = Panel,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Background,
            topBar = {
                Column(Modifier.fillMaxWidth().background(Background).padding(horizontal = 18.dp, vertical = 14.dp)) {
                    Text("DONUT X", color = NeonRed, fontSize = 27.sp, fontWeight = FontWeight.Black)
                    Text("BEDROCK COMPANION  •  VERSION 1.0.0", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF120D10)) {
                    tabs.take(5).forEach { tab ->
                        NavigationBarItem(
                            selected = current == tab,
                            onClick = { current = tab },
                            icon = { Text(tab.take(1), color = if (current == tab) NeonRed else Muted, fontWeight = FontWeight.Bold) },
                            label = { Text(tab, fontSize = 9.sp) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (current == "Home") {
                    HomeScreen(onOpen = { current = it }, pointCount = coordinates.size + bases.size, packCount = packs.size)
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Text(current.uppercase(), color = NeonRed, fontWeight = FontWeight.Black, fontSize = 20.sp)
                                TextButton(onClick = { current = "Home" }) { Text("HOME", color = Muted) }
                            }
                        }
                        when (current) {
                            "Coords" -> item { CoordinateManager(coordinates, "Saved coordinates") }
                            "Packs" -> item {
                                PackManager(packs, onImport = { packPicker.launch(arrayOf("*/*")) })
                            }
                            "Server" -> item { ServerPingScreen() }
                            "Mods" -> item { ModLibraryScreen() }
                            "PVP" -> item { PvpTrainerScreen() }
                            "Ores" -> item { OreFinderScreen() }
                            "Bases" -> item { BlockVisionScreen(bases) }
                            "Skins" -> item { SkinStudioScreen(skins, onPick = { skinPicker.launch(arrayOf("image/png", "image/jpeg", "image/webp")) }) }
                            else -> item { Text("Choose a module from Home.", color = Muted) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onOpen: (String) -> Unit, pointCount: Int, packCount: Int) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF240B12)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("COMMAND DASHBOARD", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Your Bedrock companion.", fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Text("Organize your worlds, packs and practice sessions.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        Stat("SAVED POINTS", pointCount.toString())
                        Stat("PACK ENTRIES", packCount.toString())
                        Stat("STATUS", "READY")
                    }
                }
            }
        }
        item { Text("MODULES", color = NeonRed, fontWeight = FontWeight.Bold) }
        val modules = listOf(
            "Coords" to "Coordinate Hub",
            "Packs" to "Pack Manager",
            "Server" to "Server Ping",
            "Mods" to "Mod Library",
            "PVP" to "PVP Trainer",
            "Ores" to "Ore Finder",
            "Bases" to "Base Tracker / Block Vision",
            "Skins" to "Skin Studio"
        )
        items(modules) { (key, label) ->
            Card(
                onClick = { onOpen(key) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(14.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(label, fontWeight = FontWeight.SemiBold)
                    Text("OPEN  ›", color = NeonRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Text("DONUT X is a companion app. It does not inject code into Minecraft or bypass server rules.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column {
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(label, color = Muted, fontSize = 8.sp)
    }
}

@Composable
private fun CoordinateManager(points: MutableList<SavedPoint>, heading: String) {
    var name by remember { mutableStateOf("") }
    var x by remember { mutableStateOf("") }
    var y by remember { mutableStateOf("") }
    var z by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text(heading, color = Muted, fontSize = 12.sp)
        OutlinedTextField(name, { name = it }, label = { Text("Location name") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(x, { x = it }, label = { Text("X") }, modifier = Modifier.weight(1f))
            OutlinedTextField(y, { y = it }, label = { Text("Y") }, modifier = Modifier.weight(1f))
            OutlinedTextField(z, { z = it }, label = { Text("Z") }, modifier = Modifier.weight(1f))
        }
        OutlinedTextField(note, { note = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                if (name.isNotBlank() && x.toIntOrNull() != null && y.toIntOrNull() != null && z.toIntOrNull() != null) {
                    points.add(SavedPoint(name.trim(), x.trim(), y.trim(), z.trim(), note.trim()))
                    name = ""; x = ""; y = ""; z = ""; note = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("SAVE LOCATION") }
        if (points.isEmpty()) Text("No locations saved yet.", color = Muted)
        points.forEachIndexed { index, point ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.fillMaxWidth().padding(13.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(point.name, fontWeight = FontWeight.Bold)
                        TextButton(onClick = { points.removeAt(index) }) { Text("DELETE", color = NeonRed) }
                    }
                    Text("X ${point.x}   Y ${point.y}   Z ${point.z}", color = NeonRed, fontSize = 13.sp)
                    if (point.note.isNotBlank()) Text(point.note, color = Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun PackManager(packs: List<String>, onImport: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Choose a .mcpack or .mcaddon file from Android storage. This module keeps a list of selected files; Minecraft handles importing and activation.", color = Muted, fontSize = 12.sp)
        Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) { Text("SELECT PACK FILE") }
        if (packs.isEmpty()) Text("No pack files selected.", color = Muted)
        packs.forEach { pack ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(pack, modifier = Modifier.weight(1f))
                    Text("SELECTED", color = NeonRed, fontSize = 10.sp)
                }
            }
        }
    }
}

@Composable
private fun ServerPingScreen() {
    var host by remember { mutableStateOf("play.donutsmp.net") }
    var port by remember { mutableStateOf("19132") }
    var result by remember { mutableStateOf("Enter a Bedrock server address and test it.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("RakNet unconnected ping over UDP. Results depend on server settings and network routing.", color = Muted, fontSize = 12.sp)
        OutlinedTextField(host, { host = it }, label = { Text("Server hostname / IP") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(port, { port = it }, label = { Text("UDP port") }, modifier = Modifier.fillMaxWidth())
        Button(
            enabled = !busy && host.isNotBlank() && (port.toIntOrNull()?.let { it in 1..65535 } == true),
            onClick = {
                busy = true
                result = "Testing..."
                scope.launch {
                    result = withContext(Dispatchers.IO) { rakNetPing(host.trim(), port.toInt()) }
                    busy = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (busy) "TESTING..." else "TEST SERVER") }
        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
            Text(result, Modifier.padding(15.dp), color = if (result.startsWith("Reply")) NeonRed else Color.White)
        }
    }
}

private fun rakNetPing(host: String, port: Int): String {
    return try {
        val magic = byteArrayOf(
            0x00, 0xFF.toByte(), 0xFF.toByte(), 0x00, 0xFE.toByte(), 0xFE.toByte(), 0xFE.toByte(), 0xFE.toByte(),
            0xFD.toByte(), 0xFD.toByte(), 0xFD.toByte(), 0xFD.toByte(), 0x12, 0x34, 0x56, 0x78
        )
        val timestamp = System.currentTimeMillis()
        val guid = Random.nextLong()
        val buffer = ByteBuffer.allocate(1 + 8 + 16 + 8).order(ByteOrder.BIG_ENDIAN)
        buffer.put(0x01)
        buffer.putLong(timestamp)
        buffer.put(magic)
        buffer.putLong(guid)
        val address = InetAddress.getByName(host)
        DatagramSocket().use { socket ->
            socket.soTimeout = 2500
            val outgoing = buffer.array()
            socket.send(DatagramPacket(outgoing, outgoing.size, address, port))
            val receiveBuffer = ByteArray(2048)
            val packet = DatagramPacket(receiveBuffer, receiveBuffer.size)
            socket.receive(packet)
            val elapsed = System.currentTimeMillis() - timestamp
            if (packet.length >= 1 && packet.data[0] == 0x1C.toByte()) {
                "Reply received • approximately ${elapsed} ms • ${packet.length} bytes"
            } else {
                "UDP response received (${packet.length} bytes), but it was not a recognizable RakNet pong."
            }
        }
    } catch (e: Exception) {
        "No ping reply: ${e.message ?: "timeout or network error"}. A server may block queries while still allowing gameplay."
    }
}



private data class TrackableBlock(val name: String, val group: String, val defaultColor: Color)

@Composable
private fun BlockVisionScreen(savedBases: MutableList<SavedPoint>) {
    val blocks = remember {
        listOf(
            TrackableBlock("Furnace", "Utility", Color(0xFFFF3030)),
            TrackableBlock("Chest", "Storage", Color(0xFFFFD43B)),
            TrackableBlock("Hopper", "Utility", Color(0xFFB0B0B0)),
            TrackableBlock("Note Block", "Utility", Color(0xFFB65CFF)),
            TrackableBlock("Diamond Block", "Storage", Color(0xFF20E8FF)),
            TrackableBlock("Netherite Block", "Storage", Color(0xFF777078)),
            TrackableBlock("Coal Ore", "Overworld Ore", Color(0xFF454545)),
            TrackableBlock("Deepslate Coal Ore", "Deepslate Ore", Color(0xFF737373)),
            TrackableBlock("Copper Ore", "Overworld Ore", Color(0xFFFF9B55)),
            TrackableBlock("Deepslate Copper Ore", "Deepslate Ore", Color(0xFFFFB477)),
            TrackableBlock("Iron Ore", "Overworld Ore", Color(0xFFD5D5D5)),
            TrackableBlock("Deepslate Iron Ore", "Deepslate Ore", Color(0xFFB7B7B7)),
            TrackableBlock("Gold Ore", "Overworld Ore", Color(0xFFFFD02E)),
            TrackableBlock("Deepslate Gold Ore", "Deepslate Ore", Color(0xFFFFE16A)),
            TrackableBlock("Redstone Ore", "Overworld Ore", Color(0xFFFF1744)),
            TrackableBlock("Deepslate Redstone Ore", "Deepslate Ore", Color(0xFFFF526D)),
            TrackableBlock("Lapis Lazuli Ore", "Overworld Ore", Color(0xFF3478FF)),
            TrackableBlock("Deepslate Lapis Ore", "Deepslate Ore", Color(0xFF76A2FF)),
            TrackableBlock("Diamond Ore", "Overworld Ore", Color(0xFF20E8FF)),
            TrackableBlock("Deepslate Diamond Ore", "Deepslate Ore", Color(0xFF76F3FF)),
            TrackableBlock("Emerald Ore", "Overworld Ore", Color(0xFF39FF79)),
            TrackableBlock("Deepslate Emerald Ore", "Deepslate Ore", Color(0xFF83FFAA)),
            TrackableBlock("Nether Gold Ore", "Nether Ore", Color(0xFFFFB52E)),
            TrackableBlock("Nether Quartz Ore", "Nether Ore", Color(0xFFE9D7C8)),
            TrackableBlock("Ancient Debris", "Nether Ore", Color(0xFFB87968))
        )
    }
    val enabled = remember { mutableStateListOf<String>().apply { addAll(blocks.map { it.name }) } }
    val colorChoices = listOf(
        Color(0xFFFF3030), Color(0xFFFFD43B), Color(0xFF20E8FF),
        Color(0xFFB65CFF), Color(0xFF39FF79), Color(0xFFFFFFFF),
        Color(0xFFFF8C42), Color(0xFF4D83FF), Color(0xFFFF69B4)
    )
    val selectedColors = remember { mutableStateMapOf<String, Color>().apply {
        blocks.forEach { put(it.name, it.defaultColor) }
    } }
    var radius by remember { mutableFloatStateOf(16f) }
    var showBaseForm by remember { mutableStateOf(false) }
    var baseName by remember { mutableStateOf("") }
    var baseX by remember { mutableStateOf("") }
    var baseY by remember { mutableStateOf("") }
    var baseZ by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF240B12))) {
            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                Text("BLOCK VISION", color = NeonRed, fontWeight = FontWeight.Black, fontSize = 20.sp)
                Text("Configure block filters for your own worlds or environments where scanning is explicitly allowed.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
                Text("${enabled.size} / ${blocks.size} block types enabled", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Scan radius setting: ${radius.toInt()} blocks", color = Muted, fontSize = 11.sp)
                Slider(value = radius, onValueChange = { radius = it }, valueRange = 4f..64f)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { enabled.clear(); enabled.addAll(blocks.map { it.name }) }, modifier = Modifier.weight(1f)) {
                Text("ENABLE ALL", fontSize = 10.sp)
            }
            OutlinedButton(onClick = { enabled.clear() }, modifier = Modifier.weight(1f)) {
                Text("DISABLE ALL", fontSize = 10.sp)
            }
        }
        blocks.groupBy { it.group }.forEach { (group, groupBlocks) ->
            Text(group.uppercase(), color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            groupBlocks.forEach { block ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(12.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = block.name in enabled,
                            onCheckedChange = { checked ->
                                if (checked) enabled.add(block.name) else enabled.remove(block.name)
                            }
                        )
                        Text(block.name, modifier = Modifier.weight(1f), fontSize = 12.sp)
                        Box(Modifier.size(22.dp).background(selectedColors[block.name] ?: block.defaultColor, RoundedCornerShape(5.dp)))
                        TextButton(onClick = {
                            val current = selectedColors[block.name] ?: block.defaultColor
                            val index = colorChoices.indexOf(current).let { if (it < 0) 0 else it }
                            selectedColors[block.name] = colorChoices[(index + 1) % colorChoices.size]
                        }) {
                            Text("COLOR", color = NeonRed, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
        Divider(color = Color(0xFF64202A))
        Text("AUTHORIZED BASE WAYPOINTS", color = NeonRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Text("Save coordinates you own or have permission to record.", color = Muted, fontSize = 11.sp)
        OutlinedButton(onClick = { showBaseForm = !showBaseForm }, modifier = Modifier.fillMaxWidth()) {
            Text(if (showBaseForm) "CLOSE WAYPOINT FORM" else "ADD BASE WAYPOINT")
        }
        if (showBaseForm) {
            OutlinedTextField(baseName, { baseName = it }, label = { Text("Waypoint name") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedTextField(baseX, { baseX = it }, label = { Text("X") }, modifier = Modifier.weight(1f))
                OutlinedTextField(baseY, { baseY = it }, label = { Text("Y") }, modifier = Modifier.weight(1f))
                OutlinedTextField(baseZ, { baseZ = it }, label = { Text("Z") }, modifier = Modifier.weight(1f))
            }
            Button(onClick = {
                if (baseName.isNotBlank() && baseX.toIntOrNull() != null &&
                    baseY.toIntOrNull() != null && baseZ.toIntOrNull() != null) {
                    savedBases.add(SavedPoint(baseName.trim(), baseX.trim(), baseY.trim(), baseZ.trim(), "Authorized waypoint"))
                    baseName = ""; baseX = ""; baseY = ""; baseZ = ""; showBaseForm = false
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("SAVE WAYPOINT") }
        }
        savedBases.forEachIndexed { index, point ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(point.name, fontWeight = FontWeight.Bold)
                        Text("X ${point.x}  Y ${point.y}  Z ${point.z}", color = NeonRed, fontSize = 11.sp)
                    }
                    TextButton(onClick = { savedBases.removeAt(index) }) { Text("DELETE", color = NeonRed) }
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF25131A))) {
            Text(
                "Important: this build provides block filters, colors, radius settings and waypoint records. It does not yet read live nearby blocks from Minecraft. Live scanning requires an authorized local-world integration; it will not inspect hidden blocks on Donut SMP or bypass server protections.",
                Modifier.padding(12.dp), color = Muted, fontSize = 11.sp
            )
        }
    }
}


@Composable
private fun ModLibraryScreen() {
    val entries = listOf(
        "Performance / FPS packs" to "Resource packs that simplify visuals and may reduce rendering load.",
        "Utility add-ons" to "World utility add-ons. Check version and server compatibility.",
        "Building tools" to "Creative-world building helpers.",
        "Accessibility packs" to "UI, font and readability improvements."
    )
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("A starter catalog. Add-on downloads should come from trusted creators and match your Bedrock version.", color = Muted, fontSize = 12.sp)
        entries.forEach { (title, desc) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text(title, color = NeonRed, fontWeight = FontWeight.Bold)
                    Text(desc, color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun PvpTrainerScreen() {
    val drills = listOf(
        "Strafe practice: move left and right while keeping your aim steady.",
        "Hotbar practice: switch to the correct item without looking down.",
        "Block placement: build a short safe bridge in a creative world.",
        "Movement practice: combine sprinting, jumping and direction changes.",
        "Situational awareness: practice checking surroundings before engaging."
    )
    val done = remember { mutableStateListOf<String>() }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Practice these drills in your own world or a server where training is allowed.", color = Muted, fontSize = 12.sp)
        Text("Completed ${done.size} / ${drills.size}", color = NeonRed, fontWeight = FontWeight.Bold)
        drills.forEach { drill ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = drill in done, onCheckedChange = { checked -> if (checked) done.add(drill) else done.remove(drill) })
                    Text(drill, fontSize = 12.sp, color = Color.White)
                }
            }
        }
        OutlinedButton(onClick = { done.clear() }, modifier = Modifier.fillMaxWidth()) { Text("RESET SESSION") }
    }
}

@Composable
private fun OreFinderScreen() {
    val ores = listOf(
        "Coal" to "Common at many underground heights; useful for fuel.",
        "Iron" to "Common underground; explore caves and branch mine.",
        "Copper" to "Often found in large clusters in suitable underground areas.",
        "Gold" to "More common in badlands; also found underground.",
        "Redstone" to "Look in deeper underground layers.",
        "Diamond" to "Search deep underground and explore large caves carefully.",
        "Emerald" to "Most associated with mountain biomes."
    )
    var seed by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Offline mining reference. Ore distribution varies by Bedrock version, biome and world generation. This does not scan multiplayer worlds.", color = Muted, fontSize = 12.sp)
        OutlinedTextField(seed, { seed = it }, label = { Text("Your own world seed (optional)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(note, { note = it }, label = { Text("Personal mining notes") }, modifier = Modifier.fillMaxWidth())
        Text("ORE REFERENCE", color = NeonRed, fontWeight = FontWeight.Bold)
        ores.forEach { (ore, desc) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text(ore, fontWeight = FontWeight.Bold)
                    Text(desc, color = Muted, fontSize = 11.sp)
                }
            }
        }
        if (seed.isNotBlank() || note.isNotBlank()) Text("Seed and notes are currently session-only in this starter build.", color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun SkinStudioScreen(skins: List<Uri>, onPick: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Select PNG, JPG or WebP images from your device. This starter keeps selected image references; it does not upload skins to a Microsoft account.", color = Muted, fontSize = 12.sp)
        Button(onClick = onPick, modifier = Modifier.fillMaxWidth()) { Text("CHOOSE SKIN IMAGE") }
        if (skins.isEmpty()) Text("No skin images selected.", color = Muted)
        skins.forEachIndexed { index, uri ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Text("Skin image ${index + 1}\n${uri.lastPathSegment ?: "Selected image"}", Modifier.padding(14.dp), fontSize = 12.sp)
            }
        }
    }
}
